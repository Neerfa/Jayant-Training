package com.marlabs.trainig.InheritenceTotorial;

public class Dog extends Animal {
	 public void bark(){
		System.out.println("barking...");
		}  

}
