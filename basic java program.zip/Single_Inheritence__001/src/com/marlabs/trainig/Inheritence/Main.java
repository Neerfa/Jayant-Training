package com.marlabs.trainig.Inheritence;

import com.marlabs.trainig.InheritenceTotorial.Dog;

public class Main {
	public static void main(String[] args) {
		Dog d = new Dog();
		d.bark();
		d.eat();
		// TODO Auto-generated method stub

	}

}
