package com.marlabs.training.DuckingException;

import java.util.Scanner;

public class ATM {

	public void demo() throws Exception {
		try {
			System.out.println("connection 1 established ");
			Scanner sc = new Scanner(System.in);
			System.out.println("please enter numerator");
			int n1 = sc.nextInt();
			System.out.println("please enter denomenator");
			int n2 = sc.nextInt();
			int res = n1 / n2;
			System.out.println("result is" + res);
		} finally

		{
			System.out.println("connection 1 terminated");
		}

		// TODO Auto-generated method stub

	}

}
