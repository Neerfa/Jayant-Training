package com.marlabs.training.RethroughingException;

public class Main {

	public static void main(String[] args) {
		try {
			System.out.println("main connection established");
			ATM atm=new ATM();
			atm.demo();
		}
		catch(Exception e)
		{
			System.out.println("issue reached bank");
		}
		System.out.println("main connection terminated");
		// TODO Auto-generated method stub

	}

}
