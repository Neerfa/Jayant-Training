package com.marlabs.training.ArrayindexException;

public class ArrayIndex {
	public static void main(String[] args) {
		try {
			System.out.println(4 / 1);
			try {
				int[] a = { 1, 2, 3 };
				System.out.println(a[3]);
			} catch (ArrayIndexOutOfBoundsException e) {
				System.out.println("Out of bound exception");
			}
		} catch (ArithmeticException e) {
			System.out.println("ArithmeticException : divide by 0");
		}
	}

}
