package com.marlabs.training.composition;

import com.marlabs.training.compositiontutorial.Book;
import com.marlabs.training.compositiontutorial.Student;

public class Main {
			public static void main(String[] args) {
			Student s = new Student();
			System.out.println(s.b.getColor());
			System.out.println(s.b.getWeight());
			Book bk =new Book("Java","Siddu",100);
			s.acceptBook(bk);
			/*s=null;
			System.out.println("student detroyed");*/
			}
}
