package com.marlabs.training.compositiontutorial;

public class Brain {
	String Color;
	float weight;
	
	public Brain(String color, float weight) {
		
		this.Color = color;
		this.weight = weight;
	}
	public String getColor() {
		return Color;
	}
	public float getWeight() {
		return weight;
	}
	

}
