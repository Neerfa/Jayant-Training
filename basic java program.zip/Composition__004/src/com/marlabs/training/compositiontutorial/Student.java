package com.marlabs.training.compositiontutorial;

public class Student {
		public Brain b = new Brain("red",50);
		public void acceptBook(Book ref) {
		System.out.println(ref.getName());
		System.out.println(ref.getAuthor());
		System.out.println(ref.getPrice());
		}
		
		

}
