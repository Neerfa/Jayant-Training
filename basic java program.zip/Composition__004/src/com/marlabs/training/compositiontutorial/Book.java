package com.marlabs.training.compositiontutorial;

public class Book {
	String Author;
	String Name;
	int Price;
	public Book(String author,String Name,int Price)
	{
		this.Author=author;
		this.Name=Name;
		this.Price=Price;
	}
	public String getAuthor()
	{
		return Author;
	}
	public String getName()
	{
		return Name;
	}
	public int getPrice()
	{
		return Price;
	}

}
