package com.marlabs.training.multileveleInheritencetutorial;

public class Animal {
	public void eat() {
		System.out.println("eating...");
	}

}
