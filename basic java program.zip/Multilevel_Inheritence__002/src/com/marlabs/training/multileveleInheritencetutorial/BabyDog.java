package com.marlabs.training.multileveleInheritencetutorial;

public class BabyDog extends Dog {
	public void weep() {
		System.out.println("weeping");
		
	}
}

	/*@Override
	public void bark() {
		System.out.println("baby dog barking");
	}*/


