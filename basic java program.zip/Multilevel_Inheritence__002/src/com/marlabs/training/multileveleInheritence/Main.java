package com.marlabs.training.multileveleInheritence;

import com.marlabs.training.multileveleInheritencetutorial.BabyDog;

public class Main {

	public static void main(String[] args) {
				
		BabyDog bd=new BabyDog();    
		bd.eat();
		bd.bark();
		bd.weep();
		// TODO Auto-generated method stub

	}

}
