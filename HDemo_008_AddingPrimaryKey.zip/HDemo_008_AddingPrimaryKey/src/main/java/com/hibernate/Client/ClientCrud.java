package com.hibernate.Client;


import com.hibernate.Entity.Employee;
import com.hibernate.Service.EmployeeService;
import com.hibernate.Service.impl.EmployeeServiceimpl;
import com.hibernate.model.Address;

public class ClientCrud {
	public static void main(String[] args) {
		EmployeeService employeeService= new EmployeeServiceimpl();
		try {
			Address localaddress=new Address(1092,5,21,"jayanagr","karnataka",886721);
			Address permaddress=new Address(4092,5,22,"aakshngr","karnataka",456721);

			Employee employee= new Employee("Afreen","af@af.cm",100.0);
			employee.setLocalAdress(localaddress);
			employee.setPermadress(permaddress);
			
			
			
			Integer i=employeeService.saveEmployee(employee);
			System.out.println("employee is created with this id"+i);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	
	}
}
