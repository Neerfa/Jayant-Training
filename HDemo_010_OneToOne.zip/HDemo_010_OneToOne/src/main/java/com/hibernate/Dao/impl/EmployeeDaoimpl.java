package com.hibernate.Dao.impl;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.hibernate.Dao.EmployeeDao;
import com.hibernate.Entity.Employee;
import com.hibernate.Util.Util;

public class EmployeeDaoimpl implements EmployeeDao {

	@Override
	public int saveEmployee(Employee employee) {
		Integer id=0;
		try (Session session = Util.getSessionFactory().openSession()){
			session.beginTransaction();
			id=(Integer)session.save(employee);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public Employee getEmployeeById(int employeeId) {
		Employee employee= null;
		try (Session session = Util.getSessionFactory().openSession()){
			employee= session.get(Employee.class, employeeId);
			if(employee!=null) {
				System.out.println("Employee Found!");
			}
			else {
				System.out.println("Employees not Fount with Id: "+employeeId);
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return employee;
	}

	@Override
	public void updateEmployeeById(int employeeId, Employee employeeTO) {
		try (Session session = Util.getSessionFactory().openSession()){
			Employee employee= session.get(Employee.class, employeeId);
			if(employee!= null) {
				
				//employee.setEmployeeName(employeeTO.getEmployeeName());
				//employee.setEmail(employeeTO.getEmail() );
				employee.setSalary(employeeTO.getSalary());
				
				session.beginTransaction();
				session.update(employee);
				session.getTransaction().commit();
			}
			else {
				System.out.println("Employee Not found!!");
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteEmployeeById(int employeeId) {
		try (Session session = Util.getSessionFactory().openSession()){
			Employee employee= session.get(Employee.class, employeeId);
			if(employee!= null) {
				session.beginTransaction();
				session.delete(employee);
				session.getTransaction().commit();
			}
			else {
				System.out.println("Employees not Fount with Id: "+employeeId);
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		}
	}

}
