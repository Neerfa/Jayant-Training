package com.hibernate.Entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="address1_tbl")
public class Address {
	
	@Id
	@Column(name="address_id")
    private int addressId;
	
	@Column(name="adress_id")
	private int houseno;
	private int main;
	private int crss;
	private String area;
	private String state;
	private int pincode;
	public int getHouseno() {
		return houseno;
	}
	public void setHouseno(int houseno) {
		this.houseno = houseno;
	}
	public int getMain() {
		return main;
	}
	public void setMain(int main) {
		this.main = main;
	}
	public int getCrss() {
		return crss;
	}
	public void setCrss(int crss) {
		this.crss = crss;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	
	
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public Address(int houseno, int main, int crss, String area, String state, int pincode) {
		super();
		this.houseno = houseno;
		this.main = main;
		this.crss = crss;
		this.area = area;
		this.state = state;
		this.pincode = pincode;
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		String result="------------------\nEMPLOYEE address:\n------------------\nAddress Id: \"+addressId +\" house No: "+houseno+"\n main: "+main+"\n cross: "+crss+"\n Area:"+area+"\nState:"+state+"\n pincode:"+pincode;
		return result;
	}
	

}
