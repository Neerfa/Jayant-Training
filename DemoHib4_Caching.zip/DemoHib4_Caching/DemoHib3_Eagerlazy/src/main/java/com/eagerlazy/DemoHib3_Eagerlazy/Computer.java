package com.eagerlazy.DemoHib3_Eagerlazy;

public class Computer {

}
