package com.bean;

public class CustomerBean {
	private String cid;
	private String cfname;
	private String clname;
	private String caadhar;
	private String gender;
	private String age;
	private String phnno;
	
	
	public CustomerBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CustomerBean(String cid, String cfname, String clname, String caadhar, String gender, String age,
			String phnno) {
		super();
		this.cid = cid;
		this.cfname = cfname;
		this.clname = clname;
		this.caadhar = caadhar;
		this.gender = gender;
		this.age = age;
		this.phnno = phnno;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getCfname() {
		return cfname;
	}
	public void setCfname(String cfname) {
		this.cfname = cfname;
	}
	public String getClname() {
		return clname;
	}
	public void setClname(String clname) {
		this.clname = clname;
	}
	public String getCaadhar() {
		return caadhar;
	}
	public void setCaadhar(String caadhar) {
		this.caadhar = caadhar;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getPhnno() {
		return phnno;
	}
	public void setPhnno(String phnno) {
		this.phnno = phnno;
	}
	
	
	
	

}
