package com.Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Service.CustomerService;
import com.Service.CustomerServiceImpl;
import com.bean.CustomerBean;

@WebServlet("/CustomerRegisterServlet")
public class CustomerRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cid=request.getParameter("cid");
		String cfname=request.getParameter("cfname");
		String clname=request.getParameter("clname");
		String caadhar=request.getParameter("caadhar");
		String gender=request.getParameter("gender");
		String age=request.getParameter("age");
		String phnno=request.getParameter("phnno");
		
		
		
		int result=-1;
		CustomerBean customerbean=new CustomerBean(cid,cfname,clname,caadhar,gender,age,phnno);
		CustomerService customerservice=new CustomerServiceImpl();
		if(cid!=null)
		{
			result=customerservice.addcustm(customerbean);
		}
		
		String page="customer.jsp";
		String msg="your registration Successfully completed if any query please contact bank admin";
//		if(result==-1)
//		{
//			//page="error.jsp";
//			msg="Error occured! Student not Added";
//		}
		request.setAttribute("msg", msg);
		System.out.println(result);
		System.out.println(msg);
		//Get all Students
		List<CustomerBean> custmlist=customerservice.getallcustm();
		request.setAttribute("list",custmlist );
		
		RequestDispatcher rd=request.getRequestDispatcher(page);
		rd.forward(request, response);
		
		// TODO Auto-generated method stub
	}

}
