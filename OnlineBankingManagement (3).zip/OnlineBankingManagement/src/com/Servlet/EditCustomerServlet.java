package com.Servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Service.CustomerService;
import com.Service.CustomerServiceImpl;
import com.bean.CustomerBean;



@WebServlet("/EditCustomerServlet")
public class EditCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerBean customerbean=new CustomerBean();
		CustomerService service=new CustomerServiceImpl();
		String cid=request.getParameter("cid");
		customerbean=service.getcustmbycid(cid);
		request.setAttribute("customerbean",customerbean);
		String page="editcustom.jsp";
		RequestDispatcher rd=request.getRequestDispatcher(page);
		rd.forward(request, response);
		// TODO Auto-generated method stub
	}

}
