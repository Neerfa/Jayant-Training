package com.Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Service.CustomerService;
import com.Service.CustomerServiceImpl;
import com.bean.CustomerBean;




@WebServlet("/ViewAllCustomerServlet")
public class ViewAllCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerService studentservice=new CustomerServiceImpl();
		List<CustomerBean> customers=studentservice.getallcustm();
		CustomerBean customerbean=null;
		for(int i=0;i<customers.size();i++)
		{
			customerbean=customers.get(i);
			System.out.println(customerbean.getCid()+" "+customerbean.getCfname()+" "+customerbean.getClname()+" "+customerbean.getCaadhar()+" "+customerbean.getGender()+" "+customerbean.getAge()+" "+customerbean.getPhnno());
			
			
		}
	}

		// TODO Auto-generated method stub
	}


