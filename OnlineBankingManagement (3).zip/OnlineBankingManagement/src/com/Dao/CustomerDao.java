package com.Dao;

import java.util.List;

import com.bean.CustomerBean;

public interface CustomerDao {
	public int addcustm(CustomerBean customerbean);
	public void deletecustm(String cid);
	public List<CustomerBean> getallcustm();
	public CustomerBean getcustmbycid(String cid);
	public void updatecustm(CustomerBean customerbean);
}
