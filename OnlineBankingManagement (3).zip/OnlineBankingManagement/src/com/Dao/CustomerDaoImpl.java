package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Util.Dbutil;
import com.bean.CustomerBean;

public class CustomerDaoImpl implements CustomerDao {
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	

	@Override
	public int addcustm(CustomerBean customerbean) {
		int i=-1;
		try
		{
			con=Dbutil.getMysqlConnection();
			ps=con.prepareStatement("insert into customer_tbl values(?,?,?,?,?,?,?)");
			ps.setString(1, customerbean.getCid());
			ps.setString(2,customerbean.getCfname());
			ps.setString(3,customerbean.getClname());
			ps.setString(4,customerbean.getCaadhar());
			ps.setString(5,customerbean.getGender());
			ps.setString(6,customerbean.getAge());
			ps.setString(7,customerbean.getPhnno());
			
		    i=ps.executeUpdate();
			System.out.println("From Dao :"+i);
			
		}
		catch(SQLException sqle)
		{
			sqle.printStackTrace();
		}
		finally
		{
			//System.out.println("I :"+i);
			Dbutil.cleanUp(con, ps);
		}
		return i;
		
		// TODO Auto-generated method stu
	}

	@Override
	public void deletecustm(String cid) {
		try
		{
			con=Dbutil.getMysqlConnection();
			ps=con.prepareStatement("delete from customer_tbl where cid=?");
			ps.setString(1, cid);
			ps.executeUpdate();
			
			
			
		}
		catch(SQLException sqle)
		{
			sqle.printStackTrace();
		}
		finally
		{
			
			Dbutil.cleanUp(con, ps);
		}
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<CustomerBean> getallcustm() {
		List<CustomerBean> customer=new ArrayList<CustomerBean>();
		try
		{
			con=Dbutil.getMysqlConnection();
			ps=con.prepareStatement("select * from customer_tbl");
			rs=ps.executeQuery();
			while(rs.next())
			{
				CustomerBean customerbean=new CustomerBean();
				customerbean.setCid(rs.getString(1));
				customerbean.setCfname(rs.getString(2));
				customerbean.setClname(rs.getString(3));
				customerbean.setCaadhar(rs.getString(4));
				customerbean.setGender(rs.getString(5));
				customerbean.setAge(rs.getString(6));
				customerbean.setPhnno(rs.getString(7));
				customer.add(customerbean);
			}
			
			
		}
		catch(SQLException sqle)
		{
			sqle.printStackTrace();
		}
		finally
		{
			
			Dbutil.cleanUp(rs, con, ps);
		}
		
		
		return customer;
	}

	@Override
	public CustomerBean getcustmbycid(String cid) {
		CustomerBean customerbean=new CustomerBean();
		try
		{
			
			con=Dbutil.getMysqlConnection();
			ps=con.prepareStatement("select * from customer_tbl where cid=?");
			ps.setString(1, cid);
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				
				
				customerbean.setCid(rs.getString(1));
				customerbean.setCfname(rs.getString(2));
				customerbean.setClname(rs.getString(3));
				customerbean.setCaadhar(rs.getString(4));
				customerbean.setGender(rs.getString(5));
				customerbean.setAge(rs.getString(6));
				customerbean.setPhnno(rs.getString(7));				
			}
			
			
		}
		catch(SQLException sqle)
		{
			sqle.printStackTrace();
		}
		finally
		{
			
			Dbutil.cleanUp(rs, con, ps);
		}
		
		
		return customerbean;
		
		// TODO Auto-generated method stub
	}

	@Override
	public void updatecustm(CustomerBean customerbean) {
       int rowupdated;
		
		try {
		con=Dbutil.getMysqlConnection();
		ps=con.prepareStatement("update customer_tbl set cfname=?, clname=?,caadhar=?,gender=?,age=?,phnno=? where cid=?");
		ps.setString(1,customerbean.getCfname());
		ps.setString(2,customerbean.getClname());
		ps.setString(3,customerbean.getCaadhar());
		ps.setString(4,customerbean.getGender());
		ps.setString(5,customerbean.getAge());
		ps.setString(6,customerbean.getPhnno());
		ps.setString(7,customerbean.getCid());
		rowupdated=ps.executeUpdate();
		}
		
		catch(SQLException sqle)
		{
			sqle.printStackTrace();
		}
		finally
		{
			
			Dbutil.cleanUp(rs, con, ps);
		}
		
		
		
	
		// TODO Auto-generated method stub
		
	}

}
