package com.Service;

import java.util.List;

import com.Dao.CustomerDao;
import com.Dao.CustomerDaoImpl;
import com.bean.CustomerBean;

public class CustomerServiceImpl implements CustomerService {


	public int addcustm(CustomerBean customerbean) {
		CustomerDao cdao = new CustomerDaoImpl();
		return cdao.addcustm(customerbean);
		// TODO Auto-generated method stub
		
	}

	public void deletecustm(String cid) {
		CustomerDao sdao=new CustomerDaoImpl();
		sdao.deletecustm(cid);
		// TODO Auto-generated method stub
		
	}

	public List<CustomerBean> getallcustm() {
		CustomerDao cdao=new CustomerDaoImpl();
		return cdao.getallcustm();
		// TODO Auto-generated method stub
	}


	public CustomerBean getcustmbycid(String cid) {
		CustomerDao cdao=new CustomerDaoImpl();
		return cdao.getcustmbycid(cid) ;
		// TODO Auto-generated method stub
	}

	public void updatecustm(CustomerBean customerbean) {
		CustomerDao cdao=new CustomerDaoImpl();
		cdao.updatecustm(customerbean);
		// TODO Auto-generated method stub
		
	}

}
