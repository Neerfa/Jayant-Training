package com.Service;

import java.util.List;

import com.bean.CustomerBean;

public interface CustomerService {
	public int addcustm(CustomerBean customerbean);
	public void deletecustm(String cid);
	public List<CustomerBean> getallcustm();
	public CustomerBean getcustmbycid(String cid);
	public void updatecustm(CustomerBean customerbean);

}
