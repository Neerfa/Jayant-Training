package com.hibernate.Entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import com.hibernate.model.Address;

@Entity
@Table(name="emp_tbl")
@DynamicUpdate
public class Employee {
	@Id
	@Column(name="emp_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer employeeId;
	
	@Column(name="emp_name")
	private String employeeName;
	
	private String email;
	
	private Double salary;
	
	//ValueObject
	@Embedded
	@AttributeOverrides(value={
			@AttributeOverride(column=@Column(name="local_houseno"),name="houseno"),
			@AttributeOverride(column=@Column(name="local_main"),name="main"),
			@AttributeOverride(column=@Column(name="local_crss"),name="crss"),
			@AttributeOverride(column=@Column(name="local_area"),name="area"),
			@AttributeOverride(column=@Column(name="local_state"),name="state"),
			@AttributeOverride(column=@Column(name="local_pincode"),name="pincode")
	})
	private Address localAdress;
	
	@Embedded
	@AttributeOverrides(value={
			@AttributeOverride(column=@Column(name="perm_houseno"),name="houseno"),
			@AttributeOverride(column=@Column(name="perm_main"),name="main"),
			@AttributeOverride(column=@Column(name="perm_crss"),name="crss"),
			@AttributeOverride(column=@Column(name="perm_area"),name="area"),
			@AttributeOverride(column=@Column(name="perm_state"),name="state"),
			@AttributeOverride(column=@Column(name="perm_pincode"),name="pincode")
	})
	private Address permadress;
	

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}
      
	
	public Address getLocalAdress() {
		return localAdress;
	}

	public void setLocalAdress(Address localAdress) {
		this.localAdress = localAdress;
	}

	public Address getPermadress() {
		return permadress;
	}

	public void setPermadress(Address permadress) {
		this.permadress = permadress;
	}

	public Employee(String employeeName, String email, Double salary) {
		super();
		this.employeeName = employeeName;
		this.email = email;
		this.salary = salary;
	}
	

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		String result="------------------\nEMPLOYEE Details:\n------------------\n Employee Id: "+employeeId+"\n Employee Name: "+employeeName+"\n Email: "+email+"\n Salary: "+salary;
		return result;
	}
	
	
}
