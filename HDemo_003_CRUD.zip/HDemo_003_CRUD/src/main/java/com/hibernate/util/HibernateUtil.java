package com.hibernate.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateUtil {
	//This class will create Sessionfactory
	private static StandardServiceRegistry StandardServiceRegistry;
	private static SessionFactory sessionFactory;
	static {
		try {
			if(sessionFactory==null) {
				StandardServiceRegistry=new StandardServiceRegistryBuilder().configure().build();
				MetadataSources matadatasources=new MetadataSources(StandardServiceRegistry);
				Metadata metadata=matadatasources.getMetadataBuilder().build();
				sessionFactory=metadata.getSessionFactoryBuilder().build();
			}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	public static SessionFactory getSessionFactory() {
		return sessionFactory;
		
	}

}
