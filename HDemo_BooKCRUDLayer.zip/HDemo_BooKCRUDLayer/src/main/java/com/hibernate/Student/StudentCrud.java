package com.hibernate.Student;

import com.hibernate.Entity.Book;
import com.hibernate.Service.BookService;
import com.hibernate.Service.impl.BookServiceimpl;

public class StudentCrud {

	public static void main(String[] args) {
		BookService bookService= new BookServiceimpl();
		try {
			//1. Create Book
			/*
			Book book= new Book("CS", "DennisRitche", 200.00);
			bookService.saveBook(book);
			
			
			
			//2. Read Book
			
			Integer id=1;
			System.out.println(bookService.getBookById(id));
			
			*/
		    
			//3. Update Book
		    Integer id=2;
			Book book= new Book();
			book.setBookId(2);
			book.setBookName("CS");
			book.setBookAuthor("DennisRitche");
			book.setPrice(3000.00);
			bookService.updateBookById(id, book);
				
			//4. Delete Employee
			/*
			Integer id=1;
			bookService.deleteBookById(id);
			*/
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
