package com.spring;

public class IndianShef implements Chef {

	@Override
	public String PrepareFood() {
		// TODO Auto-generated method stub
		return "tandori chicken";
	}

}
