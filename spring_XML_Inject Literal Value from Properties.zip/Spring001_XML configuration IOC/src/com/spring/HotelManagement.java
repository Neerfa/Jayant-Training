package com.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HotelManagement {
	public static void main(String args[]) {
		
		//load the configoration file
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("Spring.xml");
		
		//retrive the bean from spring container
		Chef chef=ctx.getBean("iChef",Chef.class);
		
		//call the methods
		System.out.println(chef.PrepareFood());
		
		//close the context
		ctx.close();
	}

}
