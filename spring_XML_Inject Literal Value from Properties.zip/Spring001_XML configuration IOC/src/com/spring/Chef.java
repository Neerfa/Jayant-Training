package com.spring;

public interface Chef {
	public String PrepareFood();

}
