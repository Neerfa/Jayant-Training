package com.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyTrip {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("Spring.xml");
		Car car=ctx.getBean("myCar",Car.class);
		car.letsgo();
		ctx.close();
		// TODO Auto-generated method stub

	}

}
