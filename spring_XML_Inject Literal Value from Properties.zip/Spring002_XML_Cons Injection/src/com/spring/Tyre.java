package com.spring;

public class Tyre {
	
	public String move() {
		// TODO Auto-generated method stub
		 return"moving with 120 km/hr speed";
	}

}
