package com.Bean;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyTrip {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("Spring.xml");
		Car car1=ctx.getBean("myCar",Car.class);
		Car car2=ctx.getBean("myCar",Car.class);
		/*car.letsgo();
	    System.out.println(car.getBrand());
	    System.out.println(car.getModel());*/
	    System.out.println(car1==car2);

		ctx.close();
		/*
		A a1=new A();
		A a2=new A();
		A a3=a2;
		System.out.println("____________________________________");
		System.out.println(a1==a2);
		System.out.println(a1==a3);
		// TODO Auto-generated method stub*/

	}

}
