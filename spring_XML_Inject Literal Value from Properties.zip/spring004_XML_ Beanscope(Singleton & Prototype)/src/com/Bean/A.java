package com.Bean;

public class A {

}
