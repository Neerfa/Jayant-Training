package com.Seter;

public class Car {
	//my dependency
	private Tyre t;

	//providing setter injection
	public void setT(Tyre t) {
		this.t = t;
	}
	



	void letsgo() {
		System.out.println("we are going to mysore");
		System.out.println(t.move());
	}

		
}
