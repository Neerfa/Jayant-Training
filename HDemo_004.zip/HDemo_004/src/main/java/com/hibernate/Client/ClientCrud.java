package com.hibernate.Client;

import com.hibernate.Entity.Employee;
import com.hibernate.Service.EmployeeService;
import com.hibernate.Service.impl.EmployeeServiceimpl;

public class ClientCrud {
	public static void main(String[] args) {
		EmployeeService employeeService= new EmployeeServiceimpl();
		try {
			/*1. Create Employee
			
			Employee employee= new Employee("Khushboo", "kh@jk.com", 2000.00);
			employeeService.saveEmployee(employee);
			
			
			
			//2. Read Employee
			
			Integer id=2;
			System.out.println(employeeService.getEmployeeById(id));
			
		
			//3. Update Employee
			Integer id=1;
			Employee employee= new Employee();
			employee.setEmployeeId(1);
			employee.setEmployeeName("Khushboo");
			employee.setEmail("kh@jk.com");
			employee.setSalary(4000.00);
			employeeService.updateEmployeeById(id, employee);
				*/
			//4. Delete Employee
			
			Integer id=1;
			employeeService.deleteEmployeeById(id);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
