package com.relations.DemoHib2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        
        Laptop laptop=new Laptop();
        laptop.setLid(3);
        laptop.setLname("HP");
        
        
        Student student=new Student();
        student.setRollno(003);
        student.setName("aaliya");
        student.setMarks(75);
        student.getLaptop().add(laptop);
        
        laptop.getStudent().add(student);
        
        
        Configuration con=new Configuration().configure().addAnnotatedClass(Student.class).addAnnotatedClass(Laptop.class);
        ServiceRegistry reg= new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build(); 
        SessionFactory sf= con.buildSessionFactory(reg);
        Session session=sf.openSession();
        
        session.beginTransaction();
        
        session.save(laptop);
        session.save(student);
        
        session.getTransaction().commit();
        
        
        
    }
}
