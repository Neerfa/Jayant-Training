package com.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Vulture implements Bird {
	
	Diet diet;
	
	
   



	@Qualifier("nonvegDiet")
	@Autowired
	public void setDiet(Diet diet) {
		this.diet = diet;
	}







	@Override
	public void eatstyling() {
		diet.eat();
		// TODO Auto-generated method stub
		
	}

}
