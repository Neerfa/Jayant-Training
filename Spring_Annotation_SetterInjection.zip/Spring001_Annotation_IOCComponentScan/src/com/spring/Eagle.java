package com.spring;

import org.springframework.stereotype.Component;

@Component("eagle")
public class Eagle implements Bird {

	@Override
	public void fly() {
		System.out.println("i can fly every where");
		// TODO Auto-generated method stub
		
	}

}
