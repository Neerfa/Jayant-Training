package com.spring;

import org.springframework.stereotype.Component;

@Component
public class TestBean {

	private TestBean() {
		System.out.println("Dc:TestBean");
		// TODO Auto-generated constructor stub
	}
	

}
