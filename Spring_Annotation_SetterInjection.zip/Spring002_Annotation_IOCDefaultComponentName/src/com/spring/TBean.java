package com.spring;

import org.springframework.stereotype.Component;

@Component
public class TBean {

	private TBean() {
		System.out.println("DC:TBean");
		// TODO Auto-generated constructor stub
	}
	

}
