package com.spring;

public class TestBean {
	public  TestBean() {
		System.out.println("Dc-connection");
	}
	
	public void initMethod() {
		System.out.println("init method");
		
	}
	public void destroyMethod() {
		System.out.println("destory method");
	}

}
