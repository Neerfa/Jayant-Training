package com.spring.java;

import org.springframework.stereotype.Component;

@Component
public class MyBean {
	void test() {
		System.out.println("java cofiguration");
	}

}
