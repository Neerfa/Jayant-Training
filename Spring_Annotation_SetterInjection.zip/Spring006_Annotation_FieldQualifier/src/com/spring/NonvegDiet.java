package com.spring;

import org.springframework.stereotype.Component;

@Component
public class NonvegDiet implements Diet {

	@Override
	public void eat() {
		System.out.println("red and eat");
		// TODO Auto-generated method stub
		
	}

	

}
