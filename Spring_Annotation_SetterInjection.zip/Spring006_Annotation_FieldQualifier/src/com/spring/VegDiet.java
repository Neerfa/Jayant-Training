package com.spring;

import org.springframework.stereotype.Component;

@Component
public class VegDiet implements Diet {
   
	@Override
	public void eat() {
		System.out.println("grass and beans");
		// TODO Auto-generated method stub
		
	}

	
}
