package com.spring;

public interface Bird {

	public void eatingStyle();
	

}
