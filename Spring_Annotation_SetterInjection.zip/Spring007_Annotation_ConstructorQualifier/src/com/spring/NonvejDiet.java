package com.spring;

import org.springframework.stereotype.Component;

@Component
public class NonvejDiet implements Diet {

	@Override
	public void eat() {
		System.out.println("Chicken");
		// TODO Auto-generated method stub
		
	}

}
