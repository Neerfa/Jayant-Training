package com.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringAap {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("Spring.xml");
		Bird b=ctx.getBean("vulture",Bird.class);
		b.eatingstyle();
		ctx.close();
		// TODO Auto-generated method stub

	}

}
