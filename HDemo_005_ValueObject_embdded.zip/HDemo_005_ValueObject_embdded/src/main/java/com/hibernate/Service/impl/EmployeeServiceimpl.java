package com.hibernate.Service.impl;

import com.hibernate.Dao.EmployeeDao;
import com.hibernate.Dao.impl.EmployeeDaoimpl;
import com.hibernate.Entity.Employee;
import com.hibernate.Service.EmployeeService;

public class EmployeeServiceimpl implements EmployeeService {
	EmployeeDao employeeDao= null;
	@Override
	public int saveEmployee(Employee employee) {
		employeeDao= new EmployeeDaoimpl();
		return employeeDao.saveEmployee(employee);
	}

	@Override
	public Employee getEmployeeById(int employeeId) {
		employeeDao= new EmployeeDaoimpl();
		return employeeDao.getEmployeeById(employeeId);
	}

	@Override
	public void updateEmployeeById(int employeeId, Employee employeeTO) {
		employeeDao= new EmployeeDaoimpl();
		employeeDao.updateEmployeeById(employeeId, employeeTO);
	}

	@Override
	public void deleteEmployeeById(int employeeId) {
		employeeDao= new EmployeeDaoimpl();
		employeeDao.deleteEmployeeById(employeeId);
	}

}

