package com.bean;

public class StudentBean {
	private String sid ;
	private String sname;
	private String emai;
	
	
	public StudentBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentBean(String sid, String sname, String emai) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.emai = emai;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getEmai() {
		return emai;
	}
	public void setEmai(String emai) {
		this.emai = emai;
	}
	

}
