package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.StudentBean;
import com.util.Dbutil;

public class Studentdaoimpl {
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	int i=-1;
	StudentBean studentBean=null;
	Boolean rowDeleted;

	
	public int addStudent(StudentBean studentBean) {
		try {
			con=Dbutil.getMysqlConnection();
	        ps=con.prepareStatement("insert into student_tbl values(?,?,?)");
	        ps.setString(1,studentBean.getSid()); 
	        ps.setString(2, studentBean.getSname());
	        ps.setString(3,studentBean.getEmai()); 
	        i=ps.executeUpdate(); 
	        }catch(SQLException sqle) {
	        	sqle.printStackTrace(); 
	        	} finally { 
	        		
	        		Dbutil.cleanUp(con, ps);
	        		}
		            return i;
		
		// TODO Auto-generated method stub
		
	}
public List<StudentBean> getAllUser() {
		
		List<StudentBean> students=new ArrayList<StudentBean>();
		try {
			con=Dbutil.getMysqlConnection();
			ps=con.prepareStatement("select * from student_tbl");
			rs=ps.executeQuery();
			while(rs.next()) {
				studentBean=new StudentBean();
				studentBean.setSid(rs.getString(1));
				studentBean.setSname(rs.getString(2));
				studentBean.setEmai(rs.getString(3));
				students.add(studentBean);
				
			}
		}
		catch(SQLException sqle) {
			sqle.printStackTrace();
		}
		finally {
			Dbutil.cleanUp(con, ps, rs);
		}
		// TODO Auto-generated method stub
		return students;
	}

	

}
