package com.Service;

import java.util.List;

import com.bean.StudentBean;

public interface StudentService {
	public int addStudent(StudentBean studentBean);
	public void deleteuser(String sid);
	public List<StudentBean> getAllUser();
	public StudentBean getUserBysid(String sid);
	public void updateuser(StudentBean studentbean);

}
