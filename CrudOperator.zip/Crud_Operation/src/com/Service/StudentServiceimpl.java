package com.Service;

import java.util.List;

import com.Dao.StudentDao;
import com.Dao.StudentDaoImpl;
import com.bean.StudentBean;

public class StudentServiceimpl implements StudentService {

	@Override
	public int addStudent(StudentBean studentBean) {
		StudentDao sdao = new StudentDaoImpl();
		return sdao.adduser(studentBean);
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<StudentBean> getAllUser() {
		StudentDao sdao = new StudentDaoImpl();
		return sdao.getalluser();
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteuser(String sid) {
		StudentDao sdao=new StudentDaoImpl();
		sdao.deleteuser(sid);
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public StudentBean getUserBysid(String sid) {
		StudentDao sdao=new StudentDaoImpl();
		return sdao.getUserBysid(sid) ;
		// TODO Auto-generated method stub
	}

	@Override
	public void updateuser(StudentBean studentbean) {
		StudentDao sdao=new StudentDaoImpl();
		sdao.updateuser(studentbean);
		// TODO Auto-generated method stub
		
	}


	
	

}
