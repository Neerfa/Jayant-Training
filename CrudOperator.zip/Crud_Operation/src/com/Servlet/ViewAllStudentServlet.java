package com.Servlet;

import java.util.List;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.StudentBean;
import com.Service.StudentService;
import com.Service.StudentServiceimpl;

/**
 * Servlet implementation class ViewAllStudentServlet
 */
@WebServlet("/ViewAllStudentServlet")
public class ViewAllStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StudentService studentservice=new StudentServiceimpl();
		List<StudentBean> students=studentservice.getAllUser();
		StudentBean studentbean=null;
		for(int i=0;i<students.size();i++)
		{
			studentbean=students.get(i);
			System.out.println(studentbean.getSid()+" "+studentbean.getSname()+" "+studentbean.getEmail());
			
		}
	}

}
