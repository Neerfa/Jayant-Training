create table student_tbl(
	sid varchar(10) primary key,
	sname varchar(20),
	email varchar(30)
)