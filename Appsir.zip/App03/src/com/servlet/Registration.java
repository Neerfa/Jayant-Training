package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Registration extends HttpServlet {
	
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//Reading Data
		String fname= req.getParameter("fname");
		String lname= req.getParameter("lname");
		String gender= req.getParameter("gender");
		String panNO= req.getParameter("pan");
		String aadharNo= req.getParameter("aadhar");
		String education= req.getParameter("education");
		String skills []= req.getParameterValues("skill");
		String address= req.getParameter("address");
		String email= req.getParameter("email");
		String mobileNo= req.getParameter("mobile");
		
		
		//Printing in Browser
		PrintWriter out= resp.getWriter();
		//out.println("Welcome to Web Development");
		out.println("First Name: "+fname+"<br>");
		out.println("Last Name: "+lname+"<br>");
		out.println("Gender: "+gender+"<br>");
		out.println("Pan No.: "+panNO+"<br>");
		out.println("Aadhar No.: "+aadharNo+"<br>");
		out.println("Education: "+education+"<br>");
		out.println("Skills: ");
		for(String s:skills){
			out.print("<li>"+s);
			}
		out.println("<br>");
		out.println("Address: "+address+"<br>");
		out.println("Email: "+email+"<br>");
		out.println("MobileNo: "+mobileNo+"<br>");
	}

}
