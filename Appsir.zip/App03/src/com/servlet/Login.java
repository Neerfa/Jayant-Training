package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login extends HttpServlet {
 @Override
protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	System.out.println("Welcome to servlet world");
	//Reading Data
	String username= req.getParameter("uname");
	String password= req.getParameter("pword");
	System.out.println("Username: "+username+" & Password:"+password);
	//Printing in Browser
	PrintWriter out= resp.getWriter();
	out.println("Welcome to Web Development");
	out.println("Username: "+username);
	out.println("Password: "+password);
}
}
