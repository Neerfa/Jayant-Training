package com.dis;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class Dispatcher extends HttpServlet {
	@Override
	public void init() throws ServletException {
	System.out.println("init() Called");
	super.init();
	}
	@Override
	public void init(ServletConfig config) throws ServletException {
	System.out.println("init(ServletConfig) Called");
	super.init(config);
	}
	
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	System.out.println("service Called");
	PrintWriter out= resp.getWriter();
	
	out.println("<h1>welcome to dispatcher1</h1>");
	out.println("<a href='index.jsp'>back</a>");
	RequestDispatcher rd=req.getRequestDispatcher("Dispatcher2");
	rd.forward(req, resp);
	}
	@Override
	public void destroy() {
		System.out.println("destroy called");
		super.destroy();
	}
}
	//rd.include(req, resp);
	
	


