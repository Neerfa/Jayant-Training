package com.controller;

import java.util.List;

import com.beans.Userbean;
import com.service.UserService;
import com.service.UserServiceimpl;

public class CrudOperator {
	public static void main(String args[]) {
		UserService userService=new UserServiceimpl();
		
	/*Userbean ubean=new Userbean(6789,"anu",1,"mar123");
	userService.addUser(ubean);*/
		/* Userbean ubean= new Userbean(1234, "anu", 1, "marlabs");
		 userService.updateUser(1234,ubean);*/
		//userService.deleteUser(1234);
		/*Userbean userbean=userService.getUserByaadharno(1234);
        System.out.println(userbean.getaadharno() + " " +userbean.getUsername()+" "+userbean.getUsertype()+" "+userbean.getPassword());*/
		
		List<Userbean> lst=userService.getAllUser(); 
		// 1st way-prints the elements of the List
        for (Userbean user : lst) {
            System.out.println(user.getaadharno() + " " + user.getUsername() + " " + user.getUsertype() + " "
                    + user.getPassword());
        }
		
		
	}

}
