package com.service;

import java.util.List;

import com.beans.Userbean;
import com.dao.UserDao;
import com.dao.UserDaoimpl;

public class UserServiceimpl implements UserService {
	UserDao userDao=null;

	@Override
	public void addUser(Userbean userbean) {
		userDao = new UserDaoimpl();
		userDao.addUser(userbean);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateUser(int aadharNo, Userbean userbean) {
		userDao = new UserDaoimpl();
		userDao.updateUser(aadharNo, userbean);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUser(int aadharNo) {
		userDao = new UserDaoimpl();
		userDao.deleteUser(aadharNo);
		// TODO Auto-generated method stub
		
	}

	@Override
	public Userbean getUserByaadharno(int aadharNo) {
		userDao = new UserDaoimpl();
		return userDao.getUserByaadharno(aadharNo);
		// TODO Auto-generated method stub
	}

	@Override
	public List<Userbean> getAllUser() {
		userDao = new UserDaoimpl();
		return userDao.getAllUser();
		// TODO Auto-generated method stub
	}

}
