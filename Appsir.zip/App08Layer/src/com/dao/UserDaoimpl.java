package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.beans.Userbean;
import com.util.Dbutil;

public class UserDaoimpl implements UserDao {
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	@Override
	public void addUser(Userbean userbean) {
		/*
		 * try { con=Dbutil.getMysqlConnection();
		 * ps=con.prepareStatement("insert into user_tbl values(?,?,?,?)");
		 * ps.setInt(1,userbean.getaadharno()); ps.setString(2, userbean.getUsername());
		 * ps.setInt(3, userbean.getUsertype()); ps.setString(4,
		 * userbean.getPassword()); int i=ps.executeUpdate(); }catch(SQLException sqle)
		 * { sqle.printStackTrace(); } finally { Dbutil.cleanUp(con, ps); }
		 */

	}

	// TODO Auto-generated method stub

	@Override
	public void updateUser(int aadharNo, Userbean userbean) {
		/*
		 * try { con=Dbutil.getMysqlConnection();
		 * 
		 * ps=con.prepareStatement("update user_tbl set username=? where aadharno=?");
		 * 
		 * ps.setString(1, userbean.getUsername()); ps.setInt(2,
		 * userbean.getaadharno());
		 * 
		 * 
		 * int i=ps.executeUpdate(); }catch (SQLException sqle) {
		 * sqle.printStackTrace(); } finally { Dbutil.cleanUp(con, ps); }
		 */

		// TODO Auto-generated method stub

	}

	@Override
	public void deleteUser(int aadharNo) {
		/*
		 * try { con=Dbutil.getMysqlConnection();
		 * 
		 * ps=con.prepareStatement("delete from user_tbl where aadharno=?");
		 * ps.setInt(1, aadharNo); int i=ps.executeUpdate(); }catch (SQLException sqle)
		 * { sqle.printStackTrace(); } finally { Dbutil.cleanUp(con, ps); }
		 */

		// TODO Auto-generated method stub

	}

	@Override
	public Userbean getUserByaadharno(int aadharNo) {
		// TODO Auto-generated method stub
		Userbean userbean = new Userbean();
		try {
			con = Dbutil.getMysqlConnection();

			ps = con.prepareStatement("select * from  user_tbl where aadharno=?");
			ps.setInt(1, aadharNo);

			rs = ps.executeQuery();
			while (rs.next()) {
				userbean.setaadharno(rs.getInt(1));
				userbean.setUsername(rs.getString(2));
				userbean.setUsertype(rs.getInt(3));
				userbean.setPassword(rs.getString(4));
			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			Dbutil.cleanUp(con, ps, rs);
		}

		return userbean;
	}

	@Override
	public List<Userbean> getAllUser() {
		List<Userbean> lst = new ArrayList<Userbean>();
		try {
			con = Dbutil.getMysqlConnection();

			ps = con.prepareStatement("select * from  user_tbl");

			rs = ps.executeQuery();
			while (rs.next()) {

				Userbean userbean = new Userbean();
				userbean.setaadharno(rs.getInt(1));
				userbean.setUsername(rs.getString(2));
				userbean.setUsertype(rs.getInt(3));
				userbean.setPassword(rs.getString(4));
				lst.add(userbean);
			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			Dbutil.cleanUp(con, ps, rs);
		}

		return lst;
	}
}

// TODO Auto-generated method stub