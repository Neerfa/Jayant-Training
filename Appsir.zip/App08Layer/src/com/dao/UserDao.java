package com.dao;

import java.util.List;

import com.beans.Userbean;

public interface UserDao {
	
	public void addUser(Userbean userbean);
	public void updateUser(int aadharNo, Userbean userbean);
	public void deleteUser(int aadharNo);
	public Userbean getUserByaadharno(int aadharNo);
	public List<Userbean> getAllUser();
	

}
