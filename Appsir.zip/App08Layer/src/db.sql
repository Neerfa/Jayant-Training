create table user_tbl(
aadharno int primary key,
username varchar(30),
usertype int,
password varchar(20));
);
