package com.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Insertdatabase {

	public static void main(String[] args) {
		Connection con= null;
		PreparedStatement ps= null;
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		}
		//2 Establish connection
		try {
			String url="jdbc:mysql://localhost:3306/test";
			String username="root";
			String password="Root@123";
		    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","Root@123");
			
			if(con!=null) {
				System.out.println("connection established");
			}
		
		else
		{
			System.out.println("error occured while establishing the connection");
		}
		    ps=con.prepareStatement("insert into book_tbl values(?,?,?,?)");
			ps.setString(1, "python");
			ps.setString(2, "patrick");
			ps.setInt(3,3);
			ps.setInt(4, 123);
			int i=ps.executeUpdate();
			System.out.println(i);
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally {
			try {
				if(ps!=null) {
					ps.close();
				}
				if(con!=null) {
					con.close();
				}
			}
			catch(SQLException sqle) {
				sqle.printStackTrace();
			}
		}
	}
}

		
		// TODO Auto-generated method stub

	


