package com.database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Database {
	public static void main (String args[]) {
		Connection con= null;
		PreparedStatement ps= null;
		ResultSet rs= null;
		//1 Load the driver
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		}
		//2 Establish connection
		try {
			String url="jdbc:mysql://localhost:3306/test";
			String username="root";
			String password="Root@123";
		    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","Root@123");
			
			if(con!=null) {
				System.out.println("connection established");
			}
		
		else
		{
			System.out.println("error occured while establishing the connection");
		}
		
			ps= con.prepareStatement("select * from book_tbl");
			ps= con.prepareStatement("select * from book_tbl where book_name=?");
			ps.setString(1, "j2ee");
			rs=ps.executeQuery();
			while(rs.next()) {
			System.out.println(rs.getString(1)+" : "+rs.getString(2)+" : "+rs.getInt(3)+" : "+rs.getInt(4));
			}

			} catch (SQLException e) {
			e.printStackTrace();
			}
			finally {
			try {
			if(rs!=null) {
			rs.close();
			}
			if(ps!=null) {
			ps.close();
			}
			if(con!=null) {
			con.close();
			}
			}
			catch (SQLException sqle) {
			sqle.printStackTrace();
			}
			}
			System.out.println("Done");
			}
}
	
	

			
		
		
	


