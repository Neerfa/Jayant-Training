package com.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Updatedtadbase {
	public static void main(String args[]) {
	Connection con= null;
	PreparedStatement ps= null;
	//1 Load the driver
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	}
	catch(ClassNotFoundException cnfe) {
		cnfe.printStackTrace();
	}
	//2 Establish connection
	try {
		String url="jdbc:mysql://localhost:3306/test";
		String username="root";
		String password="Root@123";
	    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","Root@123");
		
		if(con!=null) {
			System.out.println("connection established");
		}
	
	else
	{
		System.out.println("error occured while establishing the connection");
	}
		String book_name;
		String sqlupdate="UPDATE book_tbl SET book_name =? WHERE serial_no=?";
		try {
		    ps=con.prepareStatement(sqlupdate);
			ps.setString(1, "CN");
			ps.setInt(2, 2);
			ps.executeUpdate();
		}catch(SQLException sql) {
			sql.printStackTrace();
		}
	}catch(SQLException sql) {
		sql.printStackTrace();
	}
	}
}
	

		
	
	


