package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class Servlet1 extends HttpServlet {
	@Override
	public void init() throws ServletException {
	System.out.println("init() Called");
	super.init();
	}
	@Override
	public void init(ServletConfig config) throws ServletException {
	System.out.println("init(ServletConfig) Called");
	super.init(config);
	}
	
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	System.out.println("service Called");
	PrintWriter out= resp.getWriter();
	out.println("<h1>Welcome to Servlet1</h1>");
	out.println("<html>");
	out.println("<body>");
	out.println("<a href='index.jsp'>Back</a>");
	out.println("<form action='Servlet2'>");
	out.println("<input type='submit' value='Call S2'/>");
	out.println("</form>");
	out.println("</body>");
	out.println("</html>");
	}
	
	@Override
    public void destroy() {
    System.out.println("destroy() Called");
    super.destroy();
    }
    }
    
	
	
	
	
	
	
	
	


