

package com.boot.app;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloBoot {
	public static void main(String[] args) {
		SpringApplication.run(HelloBoot.class, args);
	}

}