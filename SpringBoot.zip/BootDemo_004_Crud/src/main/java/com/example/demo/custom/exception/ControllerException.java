package com.example.demo.custom.exception;

public class ControllerException {

}
