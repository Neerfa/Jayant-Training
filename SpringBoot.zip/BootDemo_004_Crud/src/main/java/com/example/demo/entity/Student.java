package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="studen_tbl")
public class Student {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
@Column(name="student_id")
private Integer studentId;
@Column(name="student_name")
private String studentName;
public Student() {
super();
// TODO Auto-generated constructor stub
}
public Student(String studentName) {
super();
this.studentName = studentName;
}
public Integer getStudentId() {
return studentId;
}
public void setStudentId(Integer studentId) {
this.studentId = studentId;
}
public String getStudentName() {
return studentName;
}
public void setStudentName(String studentName) {
this.studentName = studentName;
}

}