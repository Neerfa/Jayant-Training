package com.example.demo.custom.exception;

public class BusinessException {

}
